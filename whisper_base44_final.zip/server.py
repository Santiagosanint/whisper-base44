from flask import Flask, request, jsonify
import subprocess
import os
from werkzeug.utils import secure_filename

app = Flask(__name__)
UPLOAD_FOLDER = "./audio"
MODEL_FOLDER = "./models"
app.config["UPLOAD_FOLDER"] = UPLOAD_FOLDER

@app.route("/transcribe", methods=["POST"])
def transcribe():
    if "file" not in request.files:
        return jsonify({"error": "No file provided"}), 400

    file = request.files["file"]
    filename = secure_filename(file.filename)
    filepath = os.path.join(app.config["UPLOAD_FOLDER"], filename)
    file.save(filepath)

    command = f"./main -m {MODEL_FOLDER}/ggml-base.en.bin -f {filepath} -otxt"
    try:
        output = subprocess.check_output(command, shell=True, stderr=subprocess.STDOUT)
        with open(filepath + ".txt", "r") as f:
            transcript = f.read()
        return jsonify({"transcript": transcript})
    except subprocess.CalledProcessError as e:
        return jsonify({"error": e.output.decode()}), 500

if __name__ == "__main__":
    app.run(host="0.0.0.0", port=8080)
