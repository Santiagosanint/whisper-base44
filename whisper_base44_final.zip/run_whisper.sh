#!/bin/bash
./main -m ./models/ggml-base.en.bin -f ./audio/sample.wav -otxt
